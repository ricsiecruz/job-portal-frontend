// workaround environment config to get example working in stackblitz
export const environment = {
    apiUrl: 'http://localhost:5200/'
};