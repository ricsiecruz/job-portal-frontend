declare module '@ckeditor/ckeditor5-build-classic' {
    const ClassicEditorBuild: any;
    export = ClassicEditorBuild;
  }
  
  declare module '@ckeditor/ckeditor5-inspector' {
    const CKEditorInspector: any;
    export = CKEditorInspector;
  }
  