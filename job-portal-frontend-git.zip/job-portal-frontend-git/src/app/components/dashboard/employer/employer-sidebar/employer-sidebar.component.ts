import { Component } from '@angular/core';

@Component({
  selector: 'app-employer-sidebar',
  templateUrl: './employer-sidebar.component.html',
  styleUrls: ['./employer-sidebar.component.scss']
})
export class EmployerSidebarComponent {

}
