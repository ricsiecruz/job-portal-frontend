import { Component } from '@angular/core';

@Component({
  selector: 'app-candidate-main',
  templateUrl: './candidate-main.component.html',
  styleUrls: ['./candidate-main.component.scss']
})
export class CandidateMainComponent {

}
